git init
git remote add origin https://spider-it@bitbucket.org/spider-it/qgem-mobile
git add .
git commit -m "Initial commit"
git push -u origin master

Download 'Commit' -> Commit number
https://bitbucket.org/devguf/qgem-mobile/get/1d33c56.zip


Mit folgender URL starten:
https://139.59.129.49/qgem-mobile/

https://139.59.129.49/qgem-desktop/

Uglify:
https://skalman.github.io/

NGINX:
nginx -s reload

StartDocker:
docker start qgem-postgis

NPM Fehler anzeigen:
dmesg

NPM - Memory Problem:
npm config set jobs 1

SHUTDOWN
sudo halt -p 
sudo reboot 