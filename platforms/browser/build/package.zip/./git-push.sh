echo "Enter Push Message:"
read message
echo "You entered: $message"
git add .
git commit -m $message
git push -u origin master